"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { MenuPicker } from "@/components/menu-picker";
import { api, ApiError, inr } from "@/lib/api";
import { guestSession } from "@/lib/session";
import type { CartLine, MenuPayload } from "@/lib/types";

export default function HomePage() {
  const router = useRouter();
  const [menu, setMenu] = useState<MenuPayload | null>(null);
  const [error, setError] = useState("");
  const [cart, setCart] = useState<CartLine[]>([]);
  const [open, setOpen] = useState(false);
  const [address, setAddress] = useState("");
  const [note, setNote] = useState("");

  useEffect(() => {
    api<MenuPayload>("/api/public/menu").then(setMenu).catch((reason: unknown) => setError(reason instanceof Error ? reason.message : "Menu unavailable"));
    const saved = localStorage.getItem("restro_cart");
    if (saved) setCart(JSON.parse(saved) as CartLine[]);
  }, []);

  useEffect(() => {
    localStorage.setItem("restro_cart", JSON.stringify(cart));
  }, [cart]);

  function add(line: CartLine) {
    setCart((current) => {
      const existing = current.find((item) => item.key === line.key);
      if (!existing) return [...current, line];
      return current.map((item) => item.key === line.key ? { ...item, qty: item.qty + line.qty } : item);
    });
    toast.success(`${line.name} added`);
  }

  const total = cart.reduce((sum, line) => sum + line.price * line.qty, 0);

  async function checkout() {
    const guest = guestSession();
    if (!guest) {
      router.push("/account?next=/");
      return;
    }
    try {
      await api("/api/customer/delivery", {
        method: "POST",
        token: guest.token,
        body: JSON.stringify({
          address,
          chefNote: note,
          items: cart.map((line) => ({ menuItemId: line.menuItemId, variantId: line.variantId, optionIds: line.optionIds, qty: line.qty, note: line.note })),
        }),
      });
      setCart([]);
      setOpen(false);
      toast.success("Delivery is with the kitchen. Pay when it arrives.");
    } catch (reason) {
      toast.error(reason instanceof ApiError ? reason.message : "Could not place the delivery");
    }
  }

  return (
    <div className="mx-auto max-w-5xl px-4 pb-28 pt-6">
      <header className="flex items-end justify-between gap-4">
        <div>
          <p className="text-sm uppercase tracking-[0.25em] text-[#ff9933]">Fifteen tables</p>
          <h1 className="display text-5xl sm:text-7xl">{menu?.restaurant.name || "Restro"}</h1>
          <p className="mt-2 max-w-xl text-[#b7b1a8]">Indian, Chinese, Italian and continental, cooked for the room. Browse freely. Sign in only when you book a table or send dinner home.</p>
        </div>
        <div className="flex gap-2 text-sm">
          <Link href="/book" className="rounded-full bg-[#ff9933] px-4 py-2 font-semibold text-[#1a1208]">Book</Link>
          <Link href="/staff" className="rounded-full border border-white/15 px-4 py-2">Staff</Link>
        </div>
      </header>
      <p className="mt-4 text-sm text-[#b7b1a8]">{menu?.restaurant.hours}</p>
      {error ? <p className="mt-6 text-red-300">{error}</p> : null}
      {!menu && !error ? <p className="mt-8 text-[#b7b1a8]">Setting the tables…</p> : null}
      {menu ? <div className="mt-6"><MenuPicker menu={menu} onAdd={add} /></div> : null}
      <button type="button" className="fixed bottom-4 left-1/2 z-20 -translate-x-1/2 rounded-full bg-[#ff9933] px-5 py-3 font-semibold text-[#1a1208] shadow-lg" onClick={() => setOpen(true)}>
        Home delivery · {cart.reduce((sum, line) => sum + line.qty, 0)} · {inr(total)}
      </button>
      {open ? (
        <div className="fixed inset-0 z-30 flex items-end justify-center bg-black/60 p-3 sm:items-center">
          <div className="glass max-h-[85vh] w-full max-w-lg overflow-auto rounded-3xl p-5">
            <h2 className="display text-3xl">Send it home</h2>
            {cart.length === 0 ? <p className="mt-3 text-[#b7b1a8]">The basket is empty.</p> : cart.map((line) => (
              <div key={line.key} className="mt-3 flex items-center justify-between gap-3 text-sm">
                <span>{line.qty} × {line.name}</span>
                <button type="button" className="text-red-300" onClick={() => setCart((current) => current.filter((item) => item.key !== line.key))}>Remove</button>
              </div>
            ))}
            <label className="mt-4 block text-sm">Address
              <textarea value={address} onChange={(event) => setAddress(event.target.value)} className="mt-1 w-full rounded-xl border border-white/10 bg-black/30 px-3 py-2" rows={3} />
            </label>
            <label className="mt-3 block text-sm">Note to the chef
              <input value={note} onChange={(event) => setNote(event.target.value)} className="mt-1 w-full rounded-xl border border-white/10 bg-black/30 px-3 py-2" />
            </label>
            <div className="mt-4 flex justify-between">
              <button type="button" onClick={() => setOpen(false)} className="text-[#b7b1a8]">Close</button>
              <button type="button" onClick={checkout} className="rounded-full bg-[#ff9933] px-4 py-2 font-semibold text-[#1a1208]">Place delivery · {inr(total)}</button>
            </div>
            <p className="mt-3 text-xs text-[#b7b1a8]">Food total only. GST and any parcel charge are added on the counter bill. Payment is collected on delivery.</p>
          </div>
        </div>
      ) : null}
    </div>
  );
}
