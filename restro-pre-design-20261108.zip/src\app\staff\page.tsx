"use client";

import { Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { toast } from "sonner";
import { api, ApiError } from "@/lib/api";
import { homeFor, saveStaff } from "@/lib/session";
import type { StaffUser } from "@/lib/types";

function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const [email, setEmail] = useState("waiter@restro.com");
  const [password, setPassword] = useState("waiter123");

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    try {
      const result = await api<{ token: string; user: StaffUser }>("/api/auth/login", { method: "POST", body: JSON.stringify({ email, password }) });
      saveStaff(result.token, result.user);
      router.push(homeFor(result.user.role));
    } catch (reason) {
      toast.error(reason instanceof ApiError ? reason.message : "Could not sign in");
    }
  }

  return (
    <main className="grid min-h-screen md:grid-cols-[1.1fr_0.9fr]">
      <section className="hidden flex-col justify-between p-10 md:flex">
        <p className="display text-6xl leading-none">The floor, the pass, the bill.</p>
        <p className="max-w-md text-[#b7b1a8]">Fifteen tables. One kitchen copy of every order. Change the demo passwords before anyone outside the restaurant can reach this page.</p>
      </section>
      <section className="flex items-center px-4 py-10">
        <form onSubmit={submit} className="glass w-full max-w-md rounded-3xl p-6">
          <h1 className="display text-4xl">Staff</h1>
          {params.get("reason") === "revoked" ? <p className="mt-2 text-sm text-red-300">This session was revoked.</p> : null}
          <label className="mt-4 block text-sm">Email
            <input type="email" value={email} onChange={(event) => setEmail(event.target.value)} className="mt-1 w-full rounded-xl border border-white/10 bg-black/30 px-3 py-3" required />
          </label>
          <label className="mt-3 block text-sm">Password
            <input type="password" value={password} onChange={(event) => setPassword(event.target.value)} className="mt-1 w-full rounded-xl border border-white/10 bg-black/30 px-3 py-3" required />
          </label>
          <button className="mt-4 w-full rounded-full bg-[#ff9933] py-3 font-semibold text-[#1a1208]" type="submit">Enter</button>
          <ul className="mt-4 space-y-1 text-xs text-[#b7b1a8]">
            <li>admin@restro.com / admin123</li>
            <li>waiter@restro.com / waiter123</li>
            <li>chef@restro.com / chef123</li>
            <li>billing@restro.com / billing123</li>
          </ul>
        </form>
      </section>
    </main>
  );
}

export default function StaffPage() {
  return <Suspense fallback={<main className="p-8">Opening the staff door…</main>}><LoginForm /></Suspense>;
}
