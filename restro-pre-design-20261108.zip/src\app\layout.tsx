import type { Metadata, Viewport } from "next";
import { Manrope, Syne } from "next/font/google";
import { Providers } from "@/components/providers";
import "./globals.css";

const manrope = Manrope({ subsets: ["latin"], variable: "--font-manrope" });
const syne = Syne({ subsets: ["latin"], variable: "--font-syne" });

export const metadata: Metadata = {
  title: "Restro",
  description: "Service floor, kitchen, and billing for a 15-table dining room.",
  manifest: "/manifest.webmanifest",
  applicationName: "Restro",
};

export const viewport: Viewport = { themeColor: "#0f0f11", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={`${manrope.variable} ${syne.variable} antialiased`}>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
